<?php
include '../api/head.php';
?>
<div class="container">
  <h2>Api Tools Facebook</h2>
  
<div class="panel panel-primary">
      <div class="panel-heading">Hệ Thống GET Token Bot LOVE</div>
      <div class="panel-body">    
  <div class="list-group">
  <a class="list-group-item" href="/api/gettoken.php"><i class="fa fa-rocket"></i> Get Token IPhone Full Quyền </a>
  <a class="list-group-item" href="/index.php"><i class="fa fa-rocket"></i> Sử Dụng Bot Cảm Xúc Online </a>
  <a class="list-group-item" href="#"><i class="fa fa-rocket"></i> Đang Cập Nhật Tính Năng ... </a>
  <a class="list-group-item" href="#"> Powered by <b>Đinh Tiến Đức</b> - <b>Vnbot.xyz</b></a>
  </div>
      </div>
</div>
  
<?php
include '../api/foot.php';
?> 