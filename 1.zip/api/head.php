
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $hometitle ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:site_name" content="detail"/> 
  <meta property="og:url" content="http://autobot.systems"/> 
  <meta property="og:type" content="website"/>
  <meta property="og:title" content="AutoBot.Systems Hệ Thống Auto Bot Thả Thính , Bot Cảm Xúc Số 1 Việt Nam" /> 
  <meta property="og:description" content="Hệ Thống Bot Like Facebook Tốt Nhất Dành Cho Thanh Viên" />  
  <link rel="shortcut icon" href="https://i.imgur.com/h6NWYI8.png">
  <meta property="og:image" content="https://i.imgur.com/hiY9gsq.png" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo $home; ?>/assets/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>