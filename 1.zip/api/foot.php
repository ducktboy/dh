<br/><br/><footer><center><b>
<div class="footer">Copyrights © 2017 <font color="#ff0">AutoBot.Systems</font> <br/>Powered by TOMDZ - Hoàng Minh Thuận </div>
</b></center><br/><br/></footer>